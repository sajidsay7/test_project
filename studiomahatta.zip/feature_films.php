<?php
include_once('header.php');
?>
    <div class="site-sub-content" style="background: #808080"> <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 fullwidthsidebar"> <div class="page-list page-content-list"> <article id="page-16" class="post-16 page type-page status-publish hentry"> <div class="page-wrapper"> <div class="page-content"> <div class="page-content-body">


                                <div id="Cast" class="vc_row wpb_row vc_row-fluid container containerNoPadding"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner"><div class="wpb_wrapper"><div class="vc_empty_space" style="height: 120px"><span class="vc_empty_space_inner"></span></div><div class="content-title-element dark"><div class="title" style="color: white">feature films</div></div><div class="vc_empty_space" style="height: 75px"><span class="vc_empty_space_inner"></span></div><div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-3 vc_col-md-3 vc_col-xs-12"><div class="vc_column-inner vc_custom_1489580281947"><div class="wpb_wrapper"><div class="cast-box" style="background:white"><div class="shortbiography title_color">Bhakt Prahalad</div><div class="image"  style="padding:30px;background:white"><a href="image_details.php" title="Armas Piirainen" type="button"><img width="465" height="605" src="images/prahalad.jpg" class="attachment-themovie-cast-box size-themovie-cast-box" alt="" srcset="images/prahalad.jpg 465w, images/prahalad.jpg 231w" sizes="(max-width: 465px) 100vw, 465px"/></a></div><div class="shortbiography name_images">Post Production</div></div></div></div></div></div>

                                                <div class="vc_empty_space" style="height: 50px"><span class="vc_empty_space_inner"></span></div></div></div></div></div>
<?php
include_once('footer.php');
?>